#!/bin/bash

# add script function
source /root/script_base.sh

# add packages
PACKAGES_DEFAULT="libapache2-mod-php7.1  php7.1-fpm  php7.1-intl  php7.1-cli php7.1-cgi php7.1-curl php7.1-mcrypt php7.1-json php7.1-mysql \
                   php7.1-sqlite3 php7.1-gd php7.1-mbstring php7.1-xml php7.1-imap php7.1-bz2 php7.1-zip php-xdebug php-imagick  php-pear php-curl \

                   xfonts-utils xfonts-base xfonts-75dpi \
                   fontconfig libxrender1 php-xdebug php-soap php-curl
                   "

# update
update

# Udapte ubuntu
install_packages

a2enmod php7.1 && a2enmod rewrite 

# Configuration Apache part 2
 echo "ServerName localhost" >> /etc/apache2/apache2.conf && \
      sed -i "s/variables_order.*/variables_order = \"EGPCS\"/g" /etc/php/7.1/apache2/php.ini && \
      sed -i "s/AllowOverride None/AllowOverride All/g" /etc/apache2/apache2.conf

# Xdebug config
echo "xdebug.show_error_trace = 1" >> /etc/php/7.1/mods-available/xdebug.ini

# install wkhtmltopdf
wget http://download.gna.org/wkhtmltopdf/0.12/0.12.2.1/wkhtmltox-0.12.2.1_linux-trusty-amd64.deb && \
     dpkg -i wkhtmltox-0.12.2.1_linux-trusty-amd64.deb && \
     rm wkhtmltox-0.12.2.1_linux-trusty-amd64.deb

# Install PHPUNIT
echo "Install to phpunit --------->"
echo " "
wget https://phar.phpunit.de/phpunit.phar && \
   chmod +x phpunit.phar && \
   sudo mv phpunit.phar /usr/local/bin/phpunit && \
   phpunit --version
echo " "
echo " ===> Finish install phpunit <=== "

 # Upgrade ubuntu
 upgrade

# Clean ubuntu
 clean_ubuntu